

set -ex



fastspar --help
exit 0
